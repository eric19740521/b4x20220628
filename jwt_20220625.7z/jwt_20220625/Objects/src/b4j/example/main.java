package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 800, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button2 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _textarea1 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _textfield1 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _textfield2 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _textfield3 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _textfield4 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _textfield5 = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 28;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 29;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 30;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 31;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 34;BA.debugLine="TextField1.Text = $\"{\"alg\":\"HS256\",\"typ\":\"JWT\"}\"$";
_textfield1.setText(("{\"alg\":\"HS256\",\"typ\":\"JWT\"}"));
 //BA.debugLineNum = 36;BA.debugLine="TextField2.Text = $\"{\"sub\":\"1234567890\",\"name\":\"J";
_textfield2.setText(("{\"sub\":\"1234567890\",\"name\":\"John Doe\",\"admin\":true}"));
 //BA.debugLineNum = 39;BA.debugLine="TextField3.Text = \"\"";
_textfield3.setText("");
 //BA.debugLineNum = 41;BA.debugLine="TextField4.Text = \"\"";
_textfield4.setText("");
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public static String  _base64decode(String _s) throws Exception{
String _base64chars = "";
String _p = "";
String _r = "";
anywheresoftware.b4j.object.JavaObject _ob = null;
int _c = 0;
int _n = 0;
 //BA.debugLineNum = 214;BA.debugLine="Public Sub Base64Decode(S As String) As String";
 //BA.debugLineNum = 215;BA.debugLine="Dim base64chars As String = \"ABCDEFGHIJKLMNOPQRST";
_base64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
 //BA.debugLineNum = 216;BA.debugLine="Dim P,R = \"\" As String";
_p = "";
_r = "";
 //BA.debugLineNum = 219;BA.debugLine="Dim Ob As JavaObject = S 'ignore";
_ob = new anywheresoftware.b4j.object.JavaObject();
_ob = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_s));
 //BA.debugLineNum = 220;BA.debugLine="S=Ob.RunMethod(\"replaceAll\",Array As Object(\"[^AB";
_s = BA.ObjectToString(_ob.RunMethod("replaceAll",new Object[]{(Object)("[^ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=]"),(Object)("")}));
 //BA.debugLineNum = 225;BA.debugLine="If S.CharAt(S.Length-1)=\"=\" Then";
if (_s.charAt((int) (_s.length()-1))==BA.ObjectToChar("=")) { 
 //BA.debugLineNum = 226;BA.debugLine="If S.CharAt(S.Length-2)=\"=\" Then";
if (_s.charAt((int) (_s.length()-2))==BA.ObjectToChar("=")) { 
 //BA.debugLineNum = 227;BA.debugLine="p=\"AA\"";
_p = "AA";
 }else {
 //BA.debugLineNum = 229;BA.debugLine="P=\"A\"";
_p = "A";
 };
 }else {
 //BA.debugLineNum = 232;BA.debugLine="P=\"\"";
_p = "";
 };
 //BA.debugLineNum = 234;BA.debugLine="S=S.SubString2(0,S.Length-P.Length) & P";
_s = _s.substring((int) (0),(int) (_s.length()-_p.length()))+_p;
 //BA.debugLineNum = 236;BA.debugLine="For C = 0 To S.Length-1 Step 4";
{
final int step15 = 4;
final int limit15 = (int) (_s.length()-1);
_c = (int) (0) ;
for (;_c <= limit15 ;_c = _c + step15 ) {
 //BA.debugLineNum = 237;BA.debugLine="Try";
try { //BA.debugLineNum = 238;BA.debugLine="Dim n As Int = Bit.ShiftLeft(base64chars.IndexO";
_n = (int) (anywheresoftware.b4a.keywords.Common.Bit.ShiftLeft(_base64chars.indexOf(BA.ObjectToString(_s.charAt(_c))),(int) (18))+anywheresoftware.b4a.keywords.Common.Bit.ShiftLeft(_base64chars.indexOf(BA.ObjectToString(_s.charAt((int) (_c+1)))),(int) (12))+anywheresoftware.b4a.keywords.Common.Bit.ShiftLeft(_base64chars.indexOf(BA.ObjectToString(_s.charAt((int) (_c+2)))),(int) (6))+_base64chars.indexOf(BA.ObjectToString(_s.charAt((int) (_c+3)))));
 //BA.debugLineNum = 239;BA.debugLine="r = r & Chr(Bit.And(Bit.ShiftRight(n,16),0xFF))";
_r = _r+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr(anywheresoftware.b4a.keywords.Common.Bit.And(anywheresoftware.b4a.keywords.Common.Bit.ShiftRight(_n,(int) (16)),((int)0xff))))+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr(anywheresoftware.b4a.keywords.Common.Bit.And(anywheresoftware.b4a.keywords.Common.Bit.ShiftRight(_n,(int) (8)),((int)0xff))))+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr(anywheresoftware.b4a.keywords.Common.Bit.And(_n,((int)0xff))));
 } 
       catch (Exception e20) {
			ba.setLastException(e20); //BA.debugLineNum = 241;BA.debugLine="Log(\"Position: \" & C)";
anywheresoftware.b4a.keywords.Common.LogImpl("3458779","Position: "+BA.NumberToString(_c),0);
 };
 }
};
 //BA.debugLineNum = 245;BA.debugLine="Return R.SubString2(0, R.Length - P.Length)";
if (true) return _r.substring((int) (0),(int) (_r.length()-_p.length()));
 //BA.debugLineNum = 246;BA.debugLine="End Sub";
return "";
}
public static String  _base64encode(String _s) throws Exception{
int _c = 0;
String _base64chars = "";
String _p = "";
String _r = "";
int _n = 0;
int _n1 = 0;
int _n2 = 0;
int _n3 = 0;
int _n4 = 0;
 //BA.debugLineNum = 187;BA.debugLine="Public Sub Base64Encode(S As String) As String";
 //BA.debugLineNum = 188;BA.debugLine="Dim c As Int = S.Length Mod 3";
_c = (int) (_s.length()%3);
 //BA.debugLineNum = 189;BA.debugLine="Dim base64chars As String = \"ABCDEFGHIJKLMNOPQRST";
_base64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
 //BA.debugLineNum = 190;BA.debugLine="Dim P = \"\",R = \"\" As String";
_p = "";
_r = "";
 //BA.debugLineNum = 193;BA.debugLine="If c>0 Then";
if (_c>0) { 
 //BA.debugLineNum = 194;BA.debugLine="Do While c<3";
while (_c<3) {
 //BA.debugLineNum = 195;BA.debugLine="P = P & \"=\"";
_p = _p+"=";
 //BA.debugLineNum = 196;BA.debugLine="S = S & \"0\"";
_s = _s+"0";
 //BA.debugLineNum = 197;BA.debugLine="c=c+1";
_c = (int) (_c+1);
 }
;
 };
 //BA.debugLineNum = 201;BA.debugLine="For c = 0 To S.Length-1 Step 3";
{
final int step11 = 3;
final int limit11 = (int) (_s.length()-1);
_c = (int) (0) ;
for (;_c <= limit11 ;_c = _c + step11 ) {
 //BA.debugLineNum = 202;BA.debugLine="If (c > 0 And (c / 3 * 4) Mod 76 = 0) Then R=R &";
if ((_c>0 && (_c/(double)3*4)%76==0)) { 
_r = _r+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (10)))+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (13)));};
 //BA.debugLineNum = 203;BA.debugLine="Dim n As Int = Bit.ShiftLeft(Asc(S.CharAt(c)),16";
_n = (int) (anywheresoftware.b4a.keywords.Common.Bit.ShiftLeft(anywheresoftware.b4a.keywords.Common.Asc(_s.charAt(_c)),(int) (16))+anywheresoftware.b4a.keywords.Common.Bit.ShiftLeft(anywheresoftware.b4a.keywords.Common.Asc(_s.charAt((int) (_c+1))),(int) (8))+anywheresoftware.b4a.keywords.Common.Asc(_s.charAt((int) (_c+2))));
 //BA.debugLineNum = 204;BA.debugLine="Dim n1 As Int = Bit.And(Bit.ShiftRight(n,18),63)";
_n1 = anywheresoftware.b4a.keywords.Common.Bit.And(anywheresoftware.b4a.keywords.Common.Bit.ShiftRight(_n,(int) (18)),(int) (63));
 //BA.debugLineNum = 205;BA.debugLine="Dim n2 As Int = Bit.And(Bit.ShiftRight(n,12),63)";
_n2 = anywheresoftware.b4a.keywords.Common.Bit.And(anywheresoftware.b4a.keywords.Common.Bit.ShiftRight(_n,(int) (12)),(int) (63));
 //BA.debugLineNum = 206;BA.debugLine="Dim n3 As Int = Bit.And(Bit.ShiftRight(n,6),63)";
_n3 = anywheresoftware.b4a.keywords.Common.Bit.And(anywheresoftware.b4a.keywords.Common.Bit.ShiftRight(_n,(int) (6)),(int) (63));
 //BA.debugLineNum = 207;BA.debugLine="Dim n4 As Int = Bit.And(n,63)";
_n4 = anywheresoftware.b4a.keywords.Common.Bit.And(_n,(int) (63));
 //BA.debugLineNum = 209;BA.debugLine="R = R & base64chars.CharAt(n1) & base64chars.Cha";
_r = _r+BA.ObjectToString(_base64chars.charAt(_n1))+BA.ObjectToString(_base64chars.charAt(_n2))+BA.ObjectToString(_base64chars.charAt(_n3))+BA.ObjectToString(_base64chars.charAt(_n4));
 }
};
 //BA.debugLineNum = 211;BA.debugLine="Return r.substring2(0, r.length - p.length) & p";
if (true) return _r.substring((int) (0),(int) (_r.length()-_p.length()))+_p;
 //BA.debugLineNum = 212;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
String _header = "";
String _h = "";
String _payload = "";
String _p = "";
String _mykey = "";
String _signature = "";
String _s = "";
 //BA.debugLineNum = 48;BA.debugLine="Sub Button1_Click";
 //BA.debugLineNum = 57;BA.debugLine="TextArea1.Text = \"\"";
_textarea1.setText("");
 //BA.debugLineNum = 58;BA.debugLine="ShowMsg(\"***token start***\")";
_showmsg("***token start***");
 //BA.debugLineNum = 60;BA.debugLine="Dim header,h As String";
_header = "";
_h = "";
 //BA.debugLineNum = 62;BA.debugLine="header = TextField1.Text";
_header = _textfield1.getText();
 //BA.debugLineNum = 63;BA.debugLine="h=Base64Encode(header)";
_h = _base64encode(_header);
 //BA.debugLineNum = 64;BA.debugLine="TextField3.Text = h";
_textfield3.setText(_h);
 //BA.debugLineNum = 65;BA.debugLine="Log(\"base64Url Header=> \"&h)";
anywheresoftware.b4a.keywords.Common.LogImpl("3131089","base64Url Header=> "+_h,0);
 //BA.debugLineNum = 68;BA.debugLine="Dim payload,p As String";
_payload = "";
_p = "";
 //BA.debugLineNum = 70;BA.debugLine="payload = TextField2.Text";
_payload = _textfield2.getText();
 //BA.debugLineNum = 71;BA.debugLine="p=Base64Encode(payload)";
_p = _base64encode(_payload);
 //BA.debugLineNum = 72;BA.debugLine="TextField4.Text = p";
_textfield4.setText(_p);
 //BA.debugLineNum = 73;BA.debugLine="Log(\"base64Url Payload=>  \"&p)";
anywheresoftware.b4a.keywords.Common.LogImpl("3131097","base64Url Payload=>  "+_p,0);
 //BA.debugLineNum = 75;BA.debugLine="Dim mykey As String = \"secret\"";
_mykey = "secret";
 //BA.debugLineNum = 76;BA.debugLine="Dim signature As String=h&\".\"&p";
_signature = _h+"."+_p;
 //BA.debugLineNum = 77;BA.debugLine="Dim s As String";
_s = "";
 //BA.debugLineNum = 80;BA.debugLine="Log(\"signature==> \" &signature)";
anywheresoftware.b4a.keywords.Common.LogImpl("3131104","signature==> "+_signature,0);
 //BA.debugLineNum = 82;BA.debugLine="s = getHashBase64(CreateHash(mykey,\"HMACSHA256\",s";
_s = _gethashbase64(_createhash(_mykey,"HMACSHA256",_signature,"ASCII"));
 //BA.debugLineNum = 84;BA.debugLine="Log(\"HMACSHA256 signature=> \" &s)";
anywheresoftware.b4a.keywords.Common.LogImpl("3131108","HMACSHA256 signature=> "+_s,0);
 //BA.debugLineNum = 86;BA.debugLine="Log(\"jwt token=> \" & h &\".\"& p &\".\"& s  )";
anywheresoftware.b4a.keywords.Common.LogImpl("3131110","jwt token=> "+_h+"."+_p+"."+_s,0);
 //BA.debugLineNum = 89;BA.debugLine="TextField5.Text = h &\".\"& p &\".\"& s";
_textfield5.setText(_h+"."+_p+"."+_s);
 //BA.debugLineNum = 91;BA.debugLine="ShowMsg(\"base64Url Header=> \"&h)";
_showmsg("base64Url Header=> "+_h);
 //BA.debugLineNum = 92;BA.debugLine="ShowMsg(\"base64Url Payload=> \"&p)";
_showmsg("base64Url Payload=> "+_p);
 //BA.debugLineNum = 93;BA.debugLine="ShowMsg(\"HMACSHA256 signature=> \"&s)";
_showmsg("HMACSHA256 signature=> "+_s);
 //BA.debugLineNum = 95;BA.debugLine="ShowMsg(\"jwt token=> \" & h &\".\"& p &\".\"& s)";
_showmsg("jwt token=> "+_h+"."+_p+"."+_s);
 //BA.debugLineNum = 96;BA.debugLine="ShowMsg(\"***token End***\")";
_showmsg("***token End***");
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return "";
}
public static String  _button2_click() throws Exception{
String _s = "";
String _s1 = "";
String _s2 = "";
String _s3 = "";
String _s5 = "";
String _mykey = "";
String _signature = "";
 //BA.debugLineNum = 101;BA.debugLine="Private Sub Button2_Click";
 //BA.debugLineNum = 115;BA.debugLine="TextArea1.Text = \"\"";
_textarea1.setText("");
 //BA.debugLineNum = 116;BA.debugLine="ShowMsg(\"***start***\")";
_showmsg("***start***");
 //BA.debugLineNum = 118;BA.debugLine="Dim s,s1,s2,s3,s5 As String";
_s = "";
_s1 = "";
_s2 = "";
_s3 = "";
_s5 = "";
 //BA.debugLineNum = 120;BA.debugLine="s = TextField5.text";
_s = _textfield5.getText();
 //BA.debugLineNum = 122;BA.debugLine="s1 = s.SubString2(0, s.IndexOf(\".\"))";
_s1 = _s.substring((int) (0),_s.indexOf("."));
 //BA.debugLineNum = 123;BA.debugLine="s5 = s.SubString(s.IndexOf(\".\")+1)";
_s5 = _s.substring((int) (_s.indexOf(".")+1));
 //BA.debugLineNum = 124;BA.debugLine="s2 = s5.SubString2(0, s5.IndexOf(\".\"))";
_s2 = _s5.substring((int) (0),_s5.indexOf("."));
 //BA.debugLineNum = 125;BA.debugLine="s3 = s5.SubString(s5.IndexOf(\".\")+1)";
_s3 = _s5.substring((int) (_s5.indexOf(".")+1));
 //BA.debugLineNum = 127;BA.debugLine="ShowMsg(\"base64Url Header=> \"&s1)";
_showmsg("base64Url Header=> "+_s1);
 //BA.debugLineNum = 128;BA.debugLine="ShowMsg(\"base64Url Payload=> \"&s2)";
_showmsg("base64Url Payload=> "+_s2);
 //BA.debugLineNum = 129;BA.debugLine="ShowMsg(\"HMACSHA256 signature=> \"&s3)";
_showmsg("HMACSHA256 signature=> "+_s3);
 //BA.debugLineNum = 137;BA.debugLine="s1 = Base64Decode(s1)";
_s1 = _base64decode(_s1);
 //BA.debugLineNum = 138;BA.debugLine="s2 = Base64Decode(s2)";
_s2 = _base64decode(_s2);
 //BA.debugLineNum = 139;BA.debugLine="s3 = CalcHashAsBase64(s3)";
_s3 = _calchashasbase64(_s3);
 //BA.debugLineNum = 142;BA.debugLine="ShowMsg(\"原始內容\")";
_showmsg("原始內容");
 //BA.debugLineNum = 143;BA.debugLine="ShowMsg(\"Header=> \"&s1)";
_showmsg("Header=> "+_s1);
 //BA.debugLineNum = 144;BA.debugLine="ShowMsg(\"Payload=> \"&s2)";
_showmsg("Payload=> "+_s2);
 //BA.debugLineNum = 150;BA.debugLine="Dim mykey As String = \"secret\"";
_mykey = "secret";
 //BA.debugLineNum = 151;BA.debugLine="Dim signature As String=Base64Encode(s1)&\".\"&Base";
_signature = _base64encode(_s1)+"."+_base64encode(_s2);
 //BA.debugLineNum = 152;BA.debugLine="Dim s As String";
_s = "";
 //BA.debugLineNum = 155;BA.debugLine="ShowMsg(\"signature==> \" &signature)";
_showmsg("signature==> "+_signature);
 //BA.debugLineNum = 157;BA.debugLine="s = getHashBase64(CreateHash(mykey,\"HMACSHA256\",s";
_s = _gethashbase64(_createhash(_mykey,"HMACSHA256",_signature,"ASCII"));
 //BA.debugLineNum = 158;BA.debugLine="ShowMsg(\"HMACSHA256 signature=> \" &s)";
_showmsg("HMACSHA256 signature=> "+_s);
 //BA.debugLineNum = 163;BA.debugLine="ShowMsg(\"***end***\")";
_showmsg("***end***");
 //BA.debugLineNum = 164;BA.debugLine="End Sub";
return "";
}
public static String  _calchashasbase64(String _text) throws Exception{
anywheresoftware.b4a.agraham.encryption.CipherWrapper.MessageDigestWrapper _md = null;
byte[] _data = null;
anywheresoftware.b4a.objects.StringUtils _su = null;
 //BA.debugLineNum = 180;BA.debugLine="Sub CalcHashAsBase64 (Text As String) As String";
 //BA.debugLineNum = 181;BA.debugLine="Dim md As MessageDigest";
_md = new anywheresoftware.b4a.agraham.encryption.CipherWrapper.MessageDigestWrapper();
 //BA.debugLineNum = 182;BA.debugLine="Dim data() As Byte = md.GetMessageDigest(Text.Get";
_data = _md.GetMessageDigest(_text.getBytes("UTF8"),"SHA-512");
 //BA.debugLineNum = 183;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 184;BA.debugLine="Return su.EncodeBase64(data)";
if (true) return _su.EncodeBase64(_data);
 //BA.debugLineNum = 185;BA.debugLine="End Sub";
return "";
}
public static String  _createhash(String _key,String _algorithm,String _data,String _charset) throws Exception{
anywheresoftware.b4a.agraham.encryption.CipherWrapper.MacWrapper _m = null;
anywheresoftware.b4a.agraham.encryption.CipherWrapper.KeyGeneratorWrapper _k = null;
anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
byte[] _b = null;
 //BA.debugLineNum = 267;BA.debugLine="Sub CreateHash(key As String,algorithm As String,d";
 //BA.debugLineNum = 269;BA.debugLine="Dim m As Mac";
_m = new anywheresoftware.b4a.agraham.encryption.CipherWrapper.MacWrapper();
 //BA.debugLineNum = 270;BA.debugLine="Dim k As KeyGenerator";
_k = new anywheresoftware.b4a.agraham.encryption.CipherWrapper.KeyGeneratorWrapper();
 //BA.debugLineNum = 271;BA.debugLine="Dim bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 272;BA.debugLine="k.Initialize(algorithm)";
_k.Initialize(_algorithm);
 //BA.debugLineNum = 273;BA.debugLine="k.KeyFromBytes(key.GetBytes(charset))";
_k.KeyFromBytes(_key.getBytes(_charset));
 //BA.debugLineNum = 274;BA.debugLine="m.Initialise(algorithm, k.Key)";
_m.Initialise(_algorithm,(java.security.Key)(_k.getKey()));
 //BA.debugLineNum = 275;BA.debugLine="m.Update(data.GetBytes(charset))";
_m.Update(_data.getBytes(_charset));
 //BA.debugLineNum = 276;BA.debugLine="Dim b() As Byte";
_b = new byte[(int) (0)];
;
 //BA.debugLineNum = 277;BA.debugLine="b = m.Sign";
_b = _m.Sign();
 //BA.debugLineNum = 278;BA.debugLine="Return bc.HexFromBytes(b)";
if (true) return _bc.HexFromBytes(_b);
 //BA.debugLineNum = 280;BA.debugLine="End Sub";
return "";
}
public static String  _gethashbase64(String _inp) throws Exception{
anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
anywheresoftware.b4a.objects.StringUtils _su = null;
String _res = "";
 //BA.debugLineNum = 248;BA.debugLine="Sub getHashBase64(inp As String) As String";
 //BA.debugLineNum = 250;BA.debugLine="Dim bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 251;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 253;BA.debugLine="Dim res As String =  su.EncodeBase64(bc.HexToB";
_res = _su.EncodeBase64(_bc.HexToBytes(_inp));
 //BA.debugLineNum = 255;BA.debugLine="res=res.Replace(\"+\",\"-\")";
_res = _res.replace("+","-");
 //BA.debugLineNum = 256;BA.debugLine="res=res.Replace(\"/\",\"_\")";
_res = _res.replace("/","_");
 //BA.debugLineNum = 259;BA.debugLine="If res.EndsWith(\"=\") Then ' remove padding";
if (_res.endsWith("=")) { 
 //BA.debugLineNum = 260;BA.debugLine="res = res.Replace(\"=\",\"\")";
_res = _res.replace("=","");
 };
 //BA.debugLineNum = 263;BA.debugLine="Return res";
if (true) return _res;
 //BA.debugLineNum = 265;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 12;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 13;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 14;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 15;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Private Button2 As B4XView";
_button2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private TextArea1 As B4XView";
_textarea1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private TextField1 As B4XView";
_textfield1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private TextField2 As B4XView";
_textfield2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Private TextField3 As B4XView";
_textfield3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private TextField4 As B4XView";
_textfield4 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private TextField5 As B4XView";
_textfield5 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public static String  _showmsg(String _s) throws Exception{
 //BA.debugLineNum = 172;BA.debugLine="Sub ShowMsg(s As String)";
 //BA.debugLineNum = 174;BA.debugLine="TextArea1.Text = TextArea1.Text & s & CRLF";
_textarea1.setText(_textarea1.getText()+_s+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 178;BA.debugLine="End Sub";
return "";
}

}
